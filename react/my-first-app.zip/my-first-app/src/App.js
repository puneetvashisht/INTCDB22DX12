import logo from './logo.svg';
import './App.css';
import Message from './Message';

function App() {
  return (
    <div className="App">
      <Message></Message>
    </div>
  );
}

export default App;
