function Message(){
    return (
        <h2>Message component</h2>
    )
}
export default Message;